import casperfpga

IP = '192.168.40.67'        # This was the IP address of the ROACH2 used

fpga = casperfpga.KatcpFpga(IP)

fpga.upload_to_ram_and_program('/path/to/trans_spec.fpg')

fpga.write_int('dac_reset',1)
fpga.write_int('dac_reset',0)
fpga.write_int('start_dac',0)
fpga.write_int('start_dac',1)