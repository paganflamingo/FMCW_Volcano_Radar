import casperfpga
import numpy as np
import matplotlib.pyplot as plt

def plotFFT(fft_len):

    fig = plt.figure(figsize(8,6), facecolor = 'w', edgecolor = 'w')
    plot1 = fig.add_subplot(1, 1, 1)
    
    line, = plot1.plot(np.arange(0, fft_len), np.zeros(fft_len), '#FF4500', alpha = 0.8)
    line1.set_marker('.')

    plt.ylim(0, 5000)       # Can be adjusted for height of peaks
    plt.xlim(0, fft_len/2)  # Removes negative frequencies, can be further adjusted
    
    while True:

        fpga.write_int(regs[np.where(regs == 'fft_snap_ctrl_reg')[0][0]][1], 0)
        fpga.write_int(regs[np.where(regs == 'fft_snap_ctrl_reg')[0][0]][1], 1)
        fft_snap = (np.fromstring(fpga.read(regs[np.where(regs == 'fft_snap_bram_reg')[0][0]][1], (fft_len/2)*8), dtype='>i2')).astype('float')
        
        i0 = fft_snap[0::4]
        q0 = fft_snap[1::4]
        i1 = fft_snap[2::4]
        q1 = fft_snap[3::4]
        
        mag0 = np.sqrt(i0**2 + q0**2)
        mag1 = np.sqrt(i1**2 + q1**2)
        mags = hstack(zip(mag0,mag1))
        
        line1.set_ydata(mags)
        fig.canvas.draw()

    return

#########################################################
#                   Upload to FPGA                      #
#########################################################

run /path/to/upload.py

fft_len = 2**16
roach.write_int(regs[np.where(regs == 'fft_shift_reg')[0][0]][1], (fft_len/2) -1)

#########################################################
#                       Plot                            #
#########################################################

plt.ion()
plotFFT(fft_len)