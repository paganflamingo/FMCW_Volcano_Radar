% Define parameters
    clk_tx = 200e6;
    size_rom = 2^16;
    num_pts = 2 * size_rom;
    bw_lf_chirp = 1.5e6;

% Create frequency vector
    f = 10e6 + linspace(0, bw_lf_chirp, num_pts);
    w = 2 * pi * f;

% Create chirp vector
    t = (0:1:num_pts-1) / clk_tx;
    chirp = sin(w .* t);

% Split chirp into 2 vectors, even and odd
    S0 = chirp(1:2:end);
    S1 = chirp(2:2:end);